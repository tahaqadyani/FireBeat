import type { Metadata } from "next";
import { Vazirmatn, Lalezar, IBM_Plex_Mono, Bebas_Neue } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const vazirmatn = Vazirmatn({
  variable: "--font-vazirmatn",
  subsets: ["arabic", "latin"],
  display: "swap",
  weight: ["300", "400", "500", "700", "800"],
});

const lalezar = Lalezar({
  variable: "--font-lalezar",
  subsets: ["arabic", "latin"],
  display: "swap",
  weight: ["400"],
});

const plexMono = IBM_Plex_Mono({
  variable: "--font-plex-mono",
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600"],
});

const bebasNeue = Bebas_Neue({
  variable: "--font-bebas",
  subsets: ["latin"],
  display: "swap",
  weight: ["400"],
});

export const metadata: Metadata = {
  title: "Fire Beat — آزمایشگاه مجازی شیمی",
  description:
    "آزمایشگاه مجازی شیمی؛ اینجا عناصر را در هم می‌ریزی، واکنش را با چشم می‌بینی و جدول تناوبی را لمس می‌کنی — بدون بوی گوگرد.",
  keywords: ["Fire Beat", "آزمایشگاه مجازی", "شیمی", "جدول تناوبی", "واکنش"],
  authors: [{ name: "Fire Beat" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Fire Beat — آزمایشگاه مجازی شیمی",
    description: "آزمایشگاه مجازی شیمی، جدول تناوبی تعاملی و واکنش‌های زنده",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className={`${vazirmatn.variable} ${lalezar.variable} ${plexMono.variable} ${bebasNeue.variable} antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
