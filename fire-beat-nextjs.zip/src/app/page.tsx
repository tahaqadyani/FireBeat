'use client';

import { useEffect, useState, useSyncExternalStore } from 'react';
import FlameCanvas from '@/components/firebeat/FlameCanvas';
import Equipment from '@/components/firebeat/Equipment';
import ReactionLab from '@/components/firebeat/ReactionLab';
import PeriodicTable from '@/components/firebeat/PeriodicTable';
import Marquee from '@/components/firebeat/Marquee';
import MusicButton from '@/components/firebeat/MusicButton';
import Reveal from '@/components/firebeat/Reveal';
import { Icon } from '@/components/firebeat/Icon';

type Page = 'home' | 'equipment' | 'lab' | 'table';
const PAGES: Page[] = ['home', 'equipment', 'lab', 'table'];

function parseHash(): Page {
  if (typeof window === 'undefined') return 'home';
  const h = (window.location.hash || '#/home').replace('#/', '');
  return PAGES.includes(h as Page) ? (h as Page) : 'home';
}

function subscribeHash(cb: () => void): () => void {
  window.addEventListener('hashchange', cb);
  return () => window.removeEventListener('hashchange', cb);
}

export default function Home() {
  // Subscribe to hash changes via useSyncExternalStore to avoid
  // "setState in effect" lint warnings.
  const page = useSyncExternalStore(
    subscribeHash,
    () => parseHash(),
    () => 'home' as Page,
  );
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);

  // Avoid hydration mismatch: render a stable shell until mounted
  if (!mounted) {
    return (
      <div className="fb-root" suppressHydrationWarning>
        <nav>
          <div className="nav-in">
            <a className="brand" dir="ltr" aria-label="Fire Beat">
              <svg viewBox="0 0 32 32" fill="none">
                <path
                  d="M12 4h8M13 4v8l-6.2 12.4A4 4 0 0 0 10.4 30h11.2a4 4 0 0 0 3.6-5.6L19 12V4"
                  stroke="#ece4d4"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
                <path
                  d="M16 24.5c-2.6-2.3 1.3-5 .1-7.6 3.2 1.7 3.9 4.4 1.7 6.2"
                  fill="#f4692a"
                />
              </svg>
              Fire <em>Beat</em>
            </a>
          </div>
        </nav>
      </div>
    );
  }

  return (
    <div className="fb-root">
      {/* ناوبری */}
      <nav>
        <div className="nav-in">
          <a
            className="brand"
            href="#/home"
            dir="ltr"
            aria-label="Fire Beat"
          >
            <svg viewBox="0 0 32 32" fill="none">
              <path
                d="M12 4h8M13 4v8l-6.2 12.4A4 4 0 0 0 10.4 30h11.2a4 4 0 0 0 3.6-5.6L19 12V4"
                stroke="#ece4d4"
                strokeWidth="2"
                strokeLinecap="round"
              />
              <path
                d="M16 24.5c-2.6-2.3 1.3-5 .1-7.6 3.2 1.7 3.9 4.4 1.7 6.2"
                fill="#f4692a"
              />
            </svg>
            Fire <em>Beat</em>
          </a>
          <div className="nav-links">
            <a
              href="#/home"
              className={page === 'home' ? 'on' : ''}
            >
              خانه
            </a>
            <a
              href="#/equipment"
              className={page === 'equipment' ? 'on' : ''}
            >
              لوازم آزمایشگاهی
            </a>
            <a
              href="#/lab"
              className={page === 'lab' ? 'on' : ''}
            >
              آزمایشگاه واکنش
            </a>
            <a
              href="#/table"
              className={page === 'table' ? 'on' : ''}
            >
              جدول تناوبی
            </a>
          </div>
        </div>
      </nav>

      <main>
        {page === 'home' && (
          <section id="page-home" className="page active">
            {/* Hero */}
            <FlameCanvas active={page === 'home'}>
              <div className="hero-inner container">
                <p className="overline">VIRTUAL CHEMISTRY LAB · FIRE BEAT</p>
                <h1>
                  Fire <em>Beat</em>
                </h1>
                <p className="lead">
                  آزمایشگاه مجازی شیمی؛ اینجا عناصر را در هم می‌ریزی، واکنش را با چشم می‌بینی و جدول تناوبی را لمس می‌کنی — بدون بوی گوگرد.
                </p>
                <div className="cta">
                  <a className="btn" href="#/lab">
                    <Icon name="flame" />
                    ورود به آزمایشگاه واکنش
                  </a>
                  <a className="btn ghost" href="#/table">
                    <Icon name="atom" />
                    جدول تناوبی تعاملی
                  </a>
                </div>
                <p className="stats">
                  <span><b>۱۱۸</b> عنصر</span><i />
                  <span><b>هزاران</b> ترکیب ممکن</span><i />
                  <span><b>چهار</b> صحنه‌ی تعاملی</span>
                </p>
              </div>
            </FlameCanvas>

            <div className="hero-hint">FIRE BEAT · با ماوس در شعله بدم و برای جرقه کلیک کن</div>
          </section>
        )}

        {page === 'home' && (
          <>
            <Marquee />

            <Reveal as="section" className="quote">
              <p>
                «شیمی، هنرِ <em>دگردیسی</em> ماده است —
                <br />
                از دو گازِ بی‌نام تا قطره‌ای آب.»
              </p>
              <small>دفترچه‌ی آزمایشگاه، صفحه‌ی اول</small>
            </Reveal>
          </>
        )}

        {page === 'equipment' && (
          <section id="page-equipment" className="page active">
            <div className="container" style={{ paddingTop: 130, paddingBottom: 80 }}>
              <Equipment />
            </div>
          </section>
        )}

        {page === 'lab' && (
          <section id="page-lab" className="page active">
            <div className="container">
              <div className="lab-head">
                <p className="overline">CHAPTER 02 · REACTION LAB</p>
                <h2>آزمایشگاه واکنش</h2>
                <p className="sec-desc">
                  دو عنصر را انتخاب کن و شعله را روشن؛ ببین چطور اتم‌ها در هم می‌ریزند، جرقه می‌زنند و چیزی تازه می‌سازند — یا آرام کنار هم می‌نشینند.
                </p>
              </div>
              <ReactionLab />
            </div>
          </section>
        )}

        {page === 'table' && (
          <section id="page-table" className="page active">
            <div className="container" style={{ paddingBottom: 80 }}>
              <div className="lab-head">
                <p className="overline">CHAPTER 03 · PERIODIC TABLE</p>
                <h2>جدول تناوبی تعاملی</h2>
                <p className="sec-desc">
                  روی هر عنصر کلیک کن: عدد اتمی، جرم اتمی، آرایش الکترونی و مدل بورِ متحرکش را می‌بینی. با کلیک روی دسته‌ها، خانواده‌ها را جدا کن.
                </p>
              </div>
              <PeriodicTable />
            </div>
          </section>
        )}
      </main>

      <footer>
        <p>Fire Beat — یک آزمایشگاه مجازی؛ تمام داده‌ها و محاسبات همین‌جا در مرورگر تو زندگی می‌کنند.</p>
        <p className="mono">FIRE BEAT · NEXT.JS · NO CLOUD</p>
      </footer>

      <MusicButton />
    </div>
  );
}
