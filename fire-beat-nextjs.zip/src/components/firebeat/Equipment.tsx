'use client';

interface EquipItem {
  idx: string;
  nameFa: string;
  nameEn: string;
  desc: string;
  tag: string;
  svg: React.ReactNode;
}

const items: EquipItem[] = [
  {
    idx: '۰۱',
    nameFa: 'بشر',
    nameEn: 'BEAKER',
    desc: 'ظرف استوانه‌ای با لبه‌ی ریختن؛ برای مخلوط‌کردن، ته‌نشین‌کردن و گرم‌کردن تقریبی مایعات. اندازه‌گیری دقیق با آن معنا ندارد.',
    tag: 'شیشه‌آلات پایه',
    svg: (
      <svg className="inst" viewBox="0 0 120 150">
        <path d="M32 20 v90 a10 10 0 0 0 10 10 h36 a10 10 0 0 0 10-10 V20" />
        <path d="M32 20 l-8 -9 M88 20 h9" className="tk" />
        <path className="liq" d="M36 80 h48 v28 a8 8 0 0 1 -8 8 h-32 a8 8 0 0 1 -8 -8 z" />
        <circle className="bub" cx="52" cy="104" r="3" />
        <circle className="bub b2" cx="66" cy="107" r="2.4" />
        <circle className="bub b3" cx="59" cy="110" r="2" />
        <path d="M78 42 h8 M78 57 h8 M78 72 h8" className="tk" />
      </svg>
    ),
  },
  {
    idx: '۰۲',
    nameFa: 'ارلن مایر',
    nameEn: 'ERLENMEYER FLASK',
    desc: 'بدنه‌ی مخروطی که موج‌زدن را مهار می‌کند؛ عاشق تیتراسیون و هم‌زدن است و کم‌ترین بخار را به هوا می‌دهد.',
    tag: 'واکنش و تیتراسیون',
    svg: (
      <svg className="inst" viewBox="0 0 120 150">
        <path d="M50 16 h20 M52 16 v30 L30 112 a8 8 0 0 0 8 10 h44 a8 8 0 0 0 8 -10 L68 46 V16" />
        <path className="liq" d="M42 92 l-4 14 a6 6 0 0 0 6 8 h32 a6 6 0 0 0 6 -8 l-4 -14 z" />
        <circle className="bub" cx="55" cy="104" r="2.6" />
        <circle className="bub b2" cx="65" cy="106" r="2.2" />
        <path d="M44 70 l14 6 M40 82 l14 6" className="tk" />
      </svg>
    ),
  },
  {
    idx: '۰۳',
    nameFa: 'بالن ته‌گرد',
    nameEn: 'ROUND-BOTTOM FLASK',
    desc: 'گوی شیشه‌ای که گرما را یکنواخت پخش می‌کند؛ میزبان همیشگی جوشش، تقطیر و سنتزهای کلاسیک.',
    tag: 'حرارت و تقطیر',
    svg: (
      <svg className="inst" viewBox="0 0 120 150">
        <path d="M52 16 h16 M54 16 v40 M66 16 v40" />
        <circle cx="60" cy="94" r="36" />
        <path className="liq" d="M28 96 a32 32 0 0 0 64 0 z" />
        <circle className="bub" cx="50" cy="108" r="2.8" />
        <circle className="bub b2" cx="66" cy="112" r="2.3" />
        <circle className="bub b3" cx="58" cy="115" r="2" />
      </svg>
    ),
  },
  {
    idx: '۰۴',
    nameFa: 'استوانه‌ی مدرج',
    nameEn: 'GRADUATED CYLINDER',
    desc: 'خط‌کشِ مایعات؛ حجم را با دقت خوب اندازه می‌گیرد — به‌شرطی که چشم‌ات هم‌سطح سطح مایع باشد.',
    tag: 'اندازه‌گیری حجم',
    svg: (
      <svg className="inst" viewBox="0 0 120 150">
        <path d="M50 14 v100 a9 9 0 0 0 9 9 h5 a9 9 0 0 0 9 -9 V14" />
        <path d="M44 14 h34 M38 125 q24 9 47 0" />
        <path className="liq" d="M52 78 h20 v36 a7 7 0 0 1 -7 7 h-6 a7 7 0 0 1 -7 -7 z" />
        <circle className="bub" cx="62" cy="112" r="2.4" />
        <path d="M50 30 h8 M50 44 h8 M50 58 h8 M50 72 h8" className="tk" />
      </svg>
    ),
  },
  {
    idx: '۰۵',
    nameFa: 'لوله‌ی آزمایش',
    nameEn: 'TEST TUBE',
    desc: 'صحنه‌ی تئاتر واکنش‌های کوچک؛ از تغییر رنگ ناگهانی تا رسوب‌های شگفت‌انگیز، همه در چند قطره.',
    tag: 'واکنش‌های کوچک',
    svg: (
      <svg className="inst" viewBox="0 0 120 150">
        <path d="M44 14 h32 M48 14 v96 a12 12 0 0 0 24 0 V14" />
        <path className="liq" d="M48 82 v28 a12 12 0 0 0 24 0 V82 z" />
        <circle className="bub" cx="56" cy="102" r="2.4" />
        <circle className="bub b2" cx="65" cy="106" r="2" />
      </svg>
    ),
  },
  {
    idx: '۰۶',
    nameFa: 'بورت',
    nameEn: 'BURETTE',
    desc: 'شیردار و خوش‌دست؛ قهرمان تیتراسیون که نقطه‌ی پایان را قطره‌قطره و با وسواس اعلام می‌کند.',
    tag: 'تیتراسیون دقیق',
    svg: (
      <svg className="inst" viewBox="0 0 120 150">
        <path d="M53 12 v94 h14 V12" />
        <path d="M47 12 h26" />
        <path d="M60 106 l-4 11 h8 z" />
        <circle cx="60" cy="70" r="5" />
        <circle className="drop" cx="60" cy="127" r="2.6" />
        <path d="M53 30 h8 M53 44 h8 M53 58 h8" className="tk" />
      </svg>
    ),
  },
  {
    idx: '۰۷',
    nameFa: 'چراغ بونزن',
    nameEn: 'BUNSEN BURNER',
    desc: 'قلب تپنده‌ی آزمایشگاه؛ شعله‌ی داغ و کنترل‌شده برای گرم‌کردن، شیشه‌خم‌کردن و ضدعفونی‌کردن.',
    tag: 'منبع حرارت',
    svg: (
      <svg className="inst" viewBox="0 0 120 150">
        <path className="fO" d="M60 48 C46 34 53 22 60 8 C67 22 74 34 60 48 Z" />
        <path className="fI" d="M60 44 C54 36 57 28 60 20 C63 28 66 36 60 44 Z" />
        <path d="M50 50 h20 v40 h-20 z" />
        <path d="M46 92 h28 l7 24 h-42 z" />
        <path d="M40 122 h40" />
        <circle cx="60" cy="78" r="3" />
      </svg>
    ),
  },
];

export default function Equipment() {
  return (
    <div id="lab-equipment">
      <div className="sec-head rev">
        <p className="overline">CHAPTER 01 · LAB EQUIPMENT</p>
        <h2>لوازم آزمایشگاهی</h2>
        <p className="sec-desc">
          هر وسیله‌ای در آزمایشگاه یک شخصیت دارد؛ بعضی‌ها حوصله‌سرِ‌آمد و دقیق‌اند، بعضی‌ها آتش‌باز. با ماوس روی هر ردیف بمان تا زنده شود.
        </p>
      </div>

      <div className="eq-divider" aria-hidden="true" />

      {items.map((it, i) => (
        <div key={it.idx} className="eq-row rev" style={{ ['--i' as string]: i }}>
          <span className="eq-idx">{it.idx}</span>
          {it.svg}
          <div className="eq-name">
            <b>{it.nameFa}</b>
            <span>{it.nameEn}</span>
          </div>
          <p className="eq-desc">{it.desc}</p>
          <span className="eq-tag">{it.tag}</span>
        </div>
      ))}

      <div className="eq-divider" aria-hidden="true" />
    </div>
  );
}
