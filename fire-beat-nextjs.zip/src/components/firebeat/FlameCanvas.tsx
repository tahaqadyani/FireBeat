'use client';

import { useEffect, useRef, type ReactNode } from 'react';

interface Particle {
  x: number; y: number; vx: number; vy: number;
  r: number; l: number; ph: number;
}

interface Spark {
  x: number; y: number; vx: number; vy: number;
  r: number; l: number;
}

export default function FlameCanvas({
  active,
  children,
}: {
  active: boolean;
  children?: ReactNode;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const heroRef = useRef<HTMLDivElement | null>(null);
  const flameOnRef = useRef(false);
  const particlesRef = useRef<Particle[]>([]);
  const sparksRef = useRef<Spark[]>([]);
  const mouseRef = useRef({ x: -999, y: -999, vx: 0, lx: 0 });
  const activeRef = useRef(active);

  useEffect(() => {
    activeRef.current = active;
  }, [active]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const hero = heroRef.current;
    if (!canvas || !hero) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const resize = () => {
      canvas.width = hero.clientWidth * dpr;
      canvas.height = hero.clientHeight * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const onMove = (e: MouseEvent) => {
      const r = hero.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      mouseRef.current.vx = x - mouseRef.current.lx;
      mouseRef.current.lx = x;
      mouseRef.current.x = x;
      mouseRef.current.y = y;
    };
    const onLeave = () => {
      mouseRef.current.x = -999;
    };
    const onClick = (e: MouseEvent) => {
      const r = hero.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      for (let i = 0; i < 26; i++) {
        sparksRef.current.push({
          x, y,
          vx: (Math.random() - 0.5) * 7,
          vy: (Math.random() - 0.7) * 7,
          r: 1.5 + Math.random() * 2.5,
          l: 1,
        });
      }
    };
    hero.addEventListener('mousemove', onMove);
    hero.addEventListener('mouseleave', onLeave);
    hero.addEventListener('click', onClick);
    flameOnRef.current = true;

    let rafId = 0;
    const step = () => {
      rafId = requestAnimationFrame(step);
      if (!activeRef.current) return;
      stepFlame();
    };

    const stepFlame = () => {
      const W = canvas.clientWidth;
      const H = canvas.clientHeight;
      const cx = W / 2;
      const baseY = H - 64;

      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'source-over';

      // ambient glow
      const gl = ctx.createRadialGradient(cx, baseY - 40, 10, cx, baseY - 40, 240);
      gl.addColorStop(0, 'rgba(244,105,42,.14)');
      gl.addColorStop(1, 'rgba(244,105,42,0)');
      ctx.fillStyle = gl;
      ctx.fillRect(cx - 260, baseY - 290, 520, 300);

      // bunsen burner
      ctx.fillStyle = '#1c1712';
      ctx.strokeStyle = '#4a3f30';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(cx - 14, baseY - 118);
      ctx.lineTo(cx + 14, baseY - 118);
      ctx.lineTo(cx + 14, baseY - 34);
      ctx.lineTo(cx + 26, baseY - 8);
      ctx.lineTo(cx - 26, baseY - 8);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillRect(cx - 30, baseY - 44, 60, 12);
      ctx.strokeRect(cx - 30, baseY - 44, 60, 12);
      ctx.fillRect(cx - 66, baseY - 8, 132, 9);
      ctx.strokeRect(cx - 66, baseY - 8, 132, 9);
      ctx.beginPath();
      ctx.moveTo(cx - 12, baseY - 118);
      ctx.lineTo(cx + 12, baseY - 118);
      ctx.stroke();

      ctx.globalCompositeOperation = 'lighter';
      const t = performance.now() / 1000;

      const ps = particlesRef.current;
      for (let i = 0; i < 3; i++) {
        if (ps.length < 240) {
          ps.push({
            x: cx + (Math.random() - 0.5) * 12,
            y: baseY - 120,
            vx: (Math.random() - 0.5) * 0.5,
            vy: -(1.6 + Math.random() * 2.4),
            r: 5 + Math.random() * 9,
            l: 1,
            ph: Math.random() * 9,
          });
        }
      }

      const m = mouseRef.current;
      for (let i = ps.length - 1; i >= 0; i--) {
        const p = ps[i];
        p.l -= 0.011 + Math.random() * 0.01;
        if (p.l <= 0) {
          ps.splice(i, 1);
          continue;
        }
        p.vx += Math.sin(t * 4 + p.ph) * 0.045 + (cx - p.x) * 0.0009;
        const dm = Math.hypot(p.x - m.x, p.y - m.y);
        if (dm < 140) {
          p.vx += m.vx * 0.06 * (1 - dm / 140);
          p.vy -= 0.12 * (1 - dm / 140);
        }
        p.x += p.vx;
        p.y += p.vy;
        p.r *= 0.985;
        ctx.globalAlpha = Math.max(p.l, 0) * 0.8;
        ctx.fillStyle = p.l > 0.72 ? '#ffd9a0' : p.l > 0.4 ? '#ff8a3d' : '#c2402a';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * (0.4 + p.l * 0.6), 0, 7);
        ctx.fill();
      }

      const sp = sparksRef.current;
      for (let i = sp.length - 1; i >= 0; i--) {
        const s = sp[i];
        s.x += s.vx;
        s.y += s.vy;
        s.vy += 0.14;
        s.l -= 0.02;
        if (s.l <= 0) {
          sp.splice(i, 1);
          continue;
        }
        ctx.globalAlpha = s.l;
        ctx.fillStyle = '#ffcf8a';
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r * s.l, 0, 7);
        ctx.fill();
      }

      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
    };

    step();

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
      hero.removeEventListener('mousemove', onMove);
      hero.removeEventListener('mouseleave', onLeave);
      hero.removeEventListener('click', onClick);
      flameOnRef.current = false;
    };
  }, []);

  return (
    <div className="hero" id="hero" ref={heroRef}>
      <canvas id="flameC" ref={canvasRef} />
      {children}
    </div>
  );
}
