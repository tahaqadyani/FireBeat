'use client';

import { Flame, Atom, X, Search, Shuffle, Eraser, Link as LinkIcon, Zap, Scale, Volume2, VolumeX } from 'lucide-react';
import type { LucideProps } from 'lucide-react';

const MAP: Record<string, React.ComponentType<LucideProps>> = {
  flame: Flame,
  atom: Atom,
  x: X,
  search: Search,
  shuffle: Shuffle,
  eraser: Eraser,
  link: LinkIcon,
  zap: Zap,
  scale: Scale,
  'volume-2': Volume2,
  'volume-x': VolumeX,
};

export function Icon({ name, ...props }: { name: string } & LucideProps) {
  const C = MAP[name];
  if (!C) return null;
  return <C {...props} />;
}
