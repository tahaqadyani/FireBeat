'use client';

import { E } from '@/lib/firebeat/data';

export default function Marquee() {
  const items = E.map((e) => (
    <span key={e.z}>
      <b>{e.sym}</b> {e.fa}
    </span>
  ));
  return (
    <div className="marquee" dir="ltr">
      <div className="mq-track">
        {items}
        {items}
      </div>
    </div>
  );
}
