'use client';

import { useEffect, useRef, useState } from 'react';
import { Icon } from './Icon';

export default function MusicButton() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [userInteracted, setUserInteracted] = useState(false);
  const userRef = useRef(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const unlock = () => {
      if (userRef.current) return;
      userRef.current = true;
      setUserInteracted(true);
      try {
        audio.muted = false;
        const p = audio.play();
        if (p && typeof p.then === 'function') {
          p.then(() => setPlaying(true)).catch(() => {
            audio.muted = true;
            setPlaying(false);
          });
        } else {
          setPlaying(true);
        }
      } catch {
        setPlaying(false);
      }
      ['click', 'keydown', 'touchstart'].forEach((ev) =>
        document.removeEventListener(ev, unlock),
      );
    };

    ['click', 'keydown', 'touchstart'].forEach((ev) =>
      document.addEventListener(ev, unlock, { passive: true }),
    );

    return () => {
      ['click', 'keydown', 'touchstart'].forEach((ev) =>
        document.removeEventListener(ev, unlock),
      );
    };
  }, []);

  const onClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const audio = audioRef.current;
    if (!audio) return;

    if (!userInteracted) {
      // unlock() will fire via document listener, but force it
      const ev = new MouseEvent('click');
      document.dispatchEvent(ev);
      return;
    }

    if (audio.paused) {
      audio.muted = false;
      const p = audio.play();
      if (p && typeof p.then === 'function') {
        p.then(() => setPlaying(true)).catch(() => setPlaying(false));
      } else setPlaying(true);
    } else if (audio.muted) {
      audio.muted = false;
      setPlaying(true);
    } else {
      audio.muted = true;
      setPlaying(false);
    }
  };

  return (
    <>
      <audio
        ref={audioRef}
        loop
        autoPlay
        muted
        preload="auto"
      >
        <source src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3" type="audio/mpeg" />
      </audio>
      <button
        className={`bgm-btn ${playing ? 'on' : ''}`}
        type="button"
        aria-label="پخش یا توقف موسیقی پس‌زمینه"
        title="پخش/توقف موسیقی"
        onClick={onClick}
      >
        <Icon name={playing ? 'volume-2' : 'volume-x'} />
      </button>
    </>
  );
}
