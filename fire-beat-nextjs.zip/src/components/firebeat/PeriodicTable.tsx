'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  E, byZ, CATS, FACTS, FALLBACK, SHELL_FA, phase, place,
  type ChemElement,
} from '@/lib/firebeat/data';
import { Icon } from './Icon';

export default function PeriodicTable() {
  const [activeCat, setActiveCat] = useState<number | null>(null);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<ChemElement | null>(null);

  const q = query.trim().toLowerCase();
  const matches = useMemo(
    () =>
      E.filter((e) => {
        const okS = !q || e.fa.includes(q) || e.sym.toLowerCase().includes(q) || e.en.toLowerCase().includes(q) || String(e.z) === q;
        const okC = activeCat === null || e.cat === activeCat;
        return okS && okC;
      }),
    [q, activeCat],
  );

  const matchSet = useMemo(() => new Set(matches.map((m) => m.z)), [matches]);

  return (
    <>
      <div className="tb-tools">
        <div className="chips">
          {CATS.map((c, i) => (
            <button
              key={i}
              className={`chip ${activeCat === i ? 'on' : ''}`}
              onClick={() => setActiveCat(activeCat === i ? null : i)}
            >
              <i style={{ background: c.c }} />
              {c.n}
            </button>
          ))}
        </div>
        <div className="tb-search">
          <Icon name="search" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جست‌وجوی عنصر… (نماد یا نام)"
          />
        </div>
      </div>

      <div className="tb-wrap">
        <div className="ptable">
          <div className="el-ph" style={{ gridArea: '6 / 3' }}>
            57–71<br />
            <f>لانتانیدها</f>
          </div>
          <div className="el-ph" style={{ gridArea: '7 / 3' }}>
            89–103<br />
            <f>اکتینیدها</f>
          </div>
          {E.map((e) => {
            const [r, c] = place(e.z);
            return (
              <button
                key={e.z}
                className={`el ${matchSet.has(e.z) ? '' : 'dim'}`}
                style={{
                  ['--c' as string]: e.col,
                  ['--d' as string]: `${(r + c) * 26}ms`,
                  gridArea: `${r} / ${c}`,
                }}
                onClick={() => setSelected(e)}
              >
                <i>{e.z}</i>
                <b>{e.sym}</b>
                <span>{e.fa}</span>
              </button>
            );
          })}
        </div>
      </div>

      <p className="tb-note">
        ردیف‌های پایین، لانتانیدها و اکتینیدها هستند؛ خانواده‌هایی که بیرون از جدول می‌نشینند تا جدول نفس بکشد.
      </p>

      {selected && (
        <ElementDrawer
          el={selected}
          onClose={() => setSelected(null)}
        />
      )}
    </>
  );
}

function ElementDrawer({ el, onClose }: { el: ChemElement; onClose: () => void }) {
  const drawerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  // Build Bohr SVG
  const C = 175;
  const nR = 34;
  let bohrSvg = `<svg class="bohr" viewBox="0 0 350 350">`;
  bohrSvg += `<circle cx="${C}" cy="${C}" r="${nR + 4}" fill="${hexA(el.col, 0.14)}" stroke="${el.col}" stroke-opacity=".6"><animate attributeName="r" values="${nR + 4};${nR + 6};${nR + 4}" dur="3s" repeatCount="indefinite"/></circle>`;
  bohrSvg += `<text x="${C}" y="${C + 9}" class="bnuc">${el.sym}</text>`;
  el.sh.forEach((n, i) => {
    const r = 52 + i * 20;
    const dur = 8 + i * 5;
    bohrSvg += `<circle cx="${C}" cy="${C}" r="${r}" fill="none" stroke="rgba(236,228,212,.14)" stroke-width="1"/>`;
    let dots = '';
    for (let j = 0; j < n; j++) {
      const a = (2 * Math.PI * j) / n;
      dots += `<circle cx="${(C + r * Math.cos(a)).toFixed(1)}" cy="${(C + r * Math.sin(a)).toFixed(1)}" r="4.4" fill="${el.col}"/>`;
    }
    bohrSvg += `<g><animateTransform attributeName="transform" type="rotate" ${i % 2 ? `from="360 ${C} ${C}" to="0 ${C} ${C}"` : `from="0 ${C} ${C}" to="360 ${C} ${C}"`} dur="${dur}s" repeatCount="indefinite"/>${dots}</g>`;
  });
  bohrSvg += `</svg>`;

  const shells = el.sh.map((n, i) => (
    <span key={i}>
      {SHELL_FA[i]}: <b>{n}</b>
    </span>
  ));

  const gTxt =
    el.g === 0
      ? el.z <= 71
        ? 'لانتانیدها'
        : 'اکتینیدها'
      : 'گروه ' + el.g;

  const rows: [string, string | number][] = [
    ['عدد اتمی', el.z],
    ['جرم اتمی', `${el.m} u`],
    ['گروه / جایگاه', gTxt],
    ['دوره', el.period],
    ['دسته', CATS[el.cat].n],
    ['حالت در ۲۵ درجه', phase(el.z)],
    ['الکترونگاتیوی (پاولینگ)', el.eg || '—'],
  ];

  const fact = FACTS[el.sym] || FALLBACK[el.cat];

  return (
    <>
      <div
        className="drawer-bd open"
        onClick={onClose}
      />
      <aside
        className="drawer open"
        ref={drawerRef}
        style={{ ['--c' as string]: el.col }}
      >
        <div className="d-top">
          <span className="d-sym">{el.sym}</span>
          <div className="d-names">
            <b>{el.fa}</b>
            <span>{el.en} · Z = {el.z}</span>
          </div>
          <button className="icon-btn" onClick={onClose}>
            <Icon name="x" />
          </button>
        </div>

        <div dangerouslySetInnerHTML={{ __html: bohrSvg }} />

        <div className="d-shells">{shells}</div>

        <div className="d-rows">
          {rows.map(([k, v], i) => (
            <div className="d-row" key={k}>
              <span>{k}</span>
              <b className={i === 0 || i === 1 || i === 6 ? 'mono' : ''}>{v}</b>
            </div>
          ))}
          <div className="d-row">
            <span>آرایش الکترونی (پوسته‌ای)</span>
            <b className="mono" dir="ltr">{el.sh.join(', ')}</b>
          </div>
        </div>

        <p className="d-note">{fact}</p>
      </aside>
    </>
  );
}

function hexA(h: string, a: number): string {
  const n = parseInt(h.slice(1), 16);
  return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`;
}
