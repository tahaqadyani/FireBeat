'use client';

import { useEffect, useRef, useState } from 'react';
import {
  E, byZ, react, mixHex, hexA, toFa,
  type ChemElement, type ReactionResult,
} from '@/lib/firebeat/data';
import { Icon } from './Icon';

interface Particle {
  x: number; y: number; vx: number; vy: number;
  r: number; col: string; a?: number;
  tx?: number; ph?: number;
}

interface Bubble {
  x: number; y: number; r: number; w: number;
}

interface Spark {
  x: number; y: number; vx: number; vy: number;
  r: number; l: number;
}

type RxStateName = 'idle' | 'pour' | 'converge' | 'puff' | 'settle' | 'fizz';

interface RxState {
  parts: Particle[];
  bub: Bubble[];
  sparks: Spark[];
  state: RxStateName;
  t0: number;
  type: ReactionResult['type'] | null;
  colA: string | null;
  colB: string | null;
  colM: string | null;
  flash: number;
  ring: number;
  burstDone: boolean;
  _revealed: boolean;
}

const empty: RxState = {
  parts: [], bub: [], sparks: [],
  state: 'idle', t0: 0, type: null,
  colA: null, colB: null, colM: null,
  flash: 0, ring: 0, burstDone: false, _revealed: false,
};

export default function ReactionLab() {
  const [slotA, setSlotA] = useState<ChemElement | null>(byZ(12));
  const [slotB, setSlotB] = useState<ChemElement | null>(byZ(8));
  const [activeSlot, setActiveSlot] = useState<'A' | 'B'>('A');
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickSearch, setPickSearch] = useState('');
  const [resultVisible, setResultVisible] = useState(false);
  const [result, setResult] = useState<ReactionResult | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [flaskBusy, setFlaskBusy] = useState(false);
  const [resetTick, setResetTick] = useState(0);

  const toastTRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flaskWrapRef = useRef<HTMLDivElement | null>(null);
  const rxCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const runIdRef = useRef(0);
  const rxRef = useRef<RxState>({ ...empty });
  const rxActiveRef = useRef(false);

  const toast = (m: string) => {
    setToastMsg(m);
    if (toastTRef.current) clearTimeout(toastTRef.current);
    toastTRef.current = setTimeout(() => setToastMsg(null), 2600);
  };

  const resizeRx = () => {
    const w = flaskWrapRef.current;
    const c = rxCanvasRef.current;
    if (!w || !c) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    c.width = w.clientWidth * dpr;
    c.height = w.clientHeight * dpr;
  };

  const resetRx = () => {
    const fresh: RxState = {
      ...empty,
      parts: [], bub: [], sparks: [],
    };
    rxRef.current = fresh;
    const c = rxCanvasRef.current;
    if (c) {
      const ctx = c.getContext('2d');
      if (ctx) {
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, c.width, c.height);
      }
    }
    if (flaskWrapRef.current) flaskWrapRef.current.classList.remove('busy');
    setFlaskBusy(false);
    setResetTick((t) => t + 1);
  };

  const showResult = (res: ReactionResult, myRun: number) => {
    if (myRun !== runIdRef.current) return;
    setResult(res);
    setResultVisible(true);
  };

  const rxStep = () => {
    const c = rxCanvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;

    const rx = rxRef.current;
    const dpr = c.width / 420;
    ctx.setTransform(dpr, 0, 0, c.height / 460, 0, 0);
    ctx.clearRect(0, 0, 420, 460);

    const t = performance.now() - rx.t0;
    const CX = 210, CY = 300;

    if (rx.state === 'pour') {
      if (t < 1150 && rx.parts.length < 48) {
        for (let i = 0; i < 2; i++) {
          rx.parts.push({
            x: CX + (Math.random() - 0.5) * 26,
            y: 26,
            vx: (Math.random() - 0.5) * 0.6,
            vy: 1 + Math.random() * 1.6,
            r: 3.5 + Math.random() * 3.5,
            col: Math.random() < 0.5 ? (rx.colA as string) : (rx.colB as string),
          });
        }
      }
      if (t >= 1150) rx.state = 'converge';
    }

    for (const p of rx.parts) {
      if (rx.state === 'pour') {
        p.vy += 0.1;
        p.x += p.vx;
        p.y += p.vy;
        if (p.y > 392) {
          p.y = 392;
          p.vy *= -0.25;
          p.vx *= 0.7;
        }
      } else if (rx.state === 'converge') {
        p.vx += (CX - p.x) * 0.018;
        p.vy += (CY - p.y) * 0.018;
        p.vx *= 0.92;
        p.vy *= 0.92;
        p.x += p.vx;
        p.y += p.vy;
        p.x += Math.sin(performance.now() / 90 + p.y / 20) * 0.7;
      } else if (rx.state === 'puff') {
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.97;
        p.vy *= 0.97;
        p.a = (p.a ?? 1) - 0.012;
      } else {
        const tx = CX + (p.tx || 0);
        const ty = 400;
        p.vx += (tx - p.x) * 0.004;
        p.vy += (ty - p.y) * 0.006;
        p.vx *= 0.94;
        p.vy *= 0.94;
        p.x += p.vx + Math.sin(performance.now() / 500 + (p.ph || 0)) * 0.25;
        p.y += p.vy;
      }
    }

    if ((rx.state === 'converge' || rx.state === 'pour') && t >= 2400) {
      rx.state = rx.type === 'none' ? 'puff' : 'settle';
      rx.flash = 1;
      rx.ring = 1;
      for (let i = 0; i < 34; i++) {
        const a = Math.random() * 7;
        const s = 2 + Math.random() * 4;
        rx.sparks.push({
          x: CX, y: CY,
          vx: Math.cos(a) * s, vy: Math.sin(a) * s,
          r: 1 + Math.random() * 2.4, l: 1,
        });
      }
      if (rx.state === 'settle') {
        rx.parts.forEach((p) => {
          p.col = rx.colM as string;
          p.tx = (Math.random() - 0.5) * 150;
          p.ph = Math.random() * 9;
          p.vx = 0;
          p.vy = 0;
        });
      } else {
        rx.parts.forEach((p) => {
          const a = Math.atan2(p.y - CY, p.x - CX);
          p.vx = Math.cos(a) * 3;
          p.vy = Math.sin(a) * 3;
          p.a = 1;
          p.col = '#7a7267';
        });
      }
      if (rx.type !== 'none') {
        rx.state = 'settle';
        setTimeout(() => {
          if (rxRef.current.state === 'settle') rxRef.current.state = 'fizz';
        }, 1100);
      }
    }

    if (rx.state === 'settle' && t > 4600) rx.state = 'fizz';

    if (rx.state === 'fizz' && Math.random() < 0.14) {
      rx.bub.push({
        x: CX + (Math.random() - 0.5) * 130,
        y: 398 - Math.random() * 6,
        r: 1.5 + Math.random() * 3,
        w: Math.random() * 9,
      });
    }

    for (let i = rx.bub.length - 1; i >= 0; i--) {
      const b = rx.bub[i];
      b.y -= 0.9 + Math.random() * 0.7;
      b.x += Math.sin(performance.now() / 300 + b.w) * 0.5;
      if (b.y < 265) {
        rx.bub.splice(i, 1);
        continue;
      }
      ctx.strokeStyle = hexA(rx.colM || '#ffb454', 0.7);
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, 7);
      ctx.stroke();
    }

    if ((rx.state === 'settle' || rx.state === 'fizz') && rx.type !== 'none') {
      ctx.fillStyle = hexA(rx.colM || '#ffb454', 0.85);
      ctx.beginPath();
      ctx.ellipse(CX, 403, 84, 17, 0, 0, 7);
      ctx.fill();
    }

    for (const p of rx.parts) {
      if (p.a !== undefined && p.a <= 0) continue;
      ctx.globalAlpha = p.a !== undefined ? p.a : 0.92;
      ctx.fillStyle = p.col;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, 7);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    ctx.globalCompositeOperation = 'lighter';
    for (let i = rx.sparks.length - 1; i >= 0; i--) {
      const s = rx.sparks[i];
      s.x += s.vx;
      s.y += s.vy;
      s.vx *= 0.94;
      s.vy *= 0.94;
      s.l -= 0.03;
      if (s.l <= 0) {
        rx.sparks.splice(i, 1);
        continue;
      }
      ctx.globalAlpha = s.l;
      ctx.fillStyle = '#ffd9a0';
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, 7);
      ctx.fill();
    }
    if (rx.flash > 0.02) {
      ctx.globalAlpha = rx.flash * 0.5;
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, 420, 460);
      ctx.globalAlpha = rx.flash;
      ctx.strokeStyle = rx.colM || '#ffb454';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(CX, CY, (1 - rx.ring) * 160 + 20, 0, 7);
      ctx.stroke();
      rx.flash *= 0.9;
      rx.ring *= 0.9;
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';

    if (rx.state === 'puff' && rx.parts.every((p) => p.a !== undefined && p.a <= 0)) {
      rx.state = 'idle';
    }
  };

  const startReaction = (a: ChemElement, b: ChemElement) => {
    runIdRef.current++;
    const myRun = runIdRef.current;
    resetRx();
    setFlaskBusy(true);
    if (flaskWrapRef.current) flaskWrapRef.current.classList.add('busy');

    const res = react(a, b);
    const rx = rxRef.current;
    rx.state = 'pour';
    rx.t0 = performance.now();
    rx.type = res.type;
    rx.colA = a.col;
    rx.colB = b.col;
    rx.colM = mixHex(a.col, b.col);
    rx._revealed = false;

    const loop = () => {
      if (myRun !== runIdRef.current) return;
      requestAnimationFrame(loop);
      rxStep();
      if (
        res.type === 'cpd' &&
        res.eq &&
        rx.state !== 'pour' &&
        !rx._revealed &&
        performance.now() - rx.t0 > 2900
      ) {
        rx._revealed = true;
        showResult(res, myRun);
      } else if (
        res.type !== 'cpd' &&
        !rx._revealed &&
        performance.now() - rx.t0 > 2900
      ) {
        rx._revealed = true;
        showResult(res, myRun);
      }
    };
    loop();
  };

  // Resize canvas on mount + window resize
  useEffect(() => {
    resizeRx();
    window.addEventListener('resize', resizeRx);
    return () => window.removeEventListener('resize', resizeRx);
  }, []);

  // Continuous animation loop
  useEffect(() => {
    let rafId = 0;
    const loop = () => {
      rafId = requestAnimationFrame(loop);
      if (rxRef.current.state !== 'idle') rxStep();
    };
    loop();
    return () => cancelAnimationFrame(rafId);
  }, []);

  const pickFilter = (e: ChemElement, q: string): boolean => {
    if (!q) return true;
    return (
      e.fa.includes(q) ||
      e.sym.toLowerCase().includes(q) ||
      e.en.toLowerCase().includes(q) ||
      String(e.z) === q
    );
  };

  const openPicker = (k: 'A' | 'B') => {
    setActiveSlot(k);
    setPickerOpen(true);
    setPickSearch('');
  };

  const handlePick = (z: number) => {
    const el = byZ(z);
    if (activeSlot === 'A') setSlotA(el);
    else setSlotB(el);
    setPickerOpen(false);
    if (slotA && slotB) toast('هر دو ظرف آماده است؛ شعله را روشن کن!');
  };

  const onMix = () => {
    if (!slotA || !slotB) {
      toast('اول هر دو ظرف را پر کن.');
      return;
    }
    setResultVisible(false);
    startReaction(slotA, slotB);
  };

  const onRandom = () => {
    const z1 = 1 + Math.floor(Math.random() * 118);
    let z2: number;
    do { z2 = 1 + Math.floor(Math.random() * 118); } while (z2 === z1);
    const a = byZ(z1);
    const b = byZ(z2);
    setSlotA(a);
    setSlotB(b);
    toast(`شانسی: ${a.fa} + ${b.fa} — بزن بریم!`);
    setResultVisible(false);
    startReaction(a, b);
  };

  const onClear = () => {
    runIdRef.current++;
    resetRx();
    setSlotA(null);
    setSlotB(null);
    setResultVisible(false);
  };

  const onFamous = (z1: number, z2: number) => {
    const a = byZ(z1);
    const b = byZ(z2);
    setSlotA(a);
    setSlotB(b);
    setResultVisible(false);
    startReaction(a, b);
  };

  const pickQ = pickSearch.trim().toLowerCase();

  return (
    <>
      <div className="bench">
        <button
          className={`slot slotA ${slotA ? 'filled' : ''}`}
          style={{ ['--c' as string]: slotA?.col || 'transparent' }}
          onClick={(e) => {
            if ((e.target as HTMLElement).closest('.s-x')) {
              setSlotA(null);
              return;
            }
            openPicker('A');
          }}
        >
          {slotA ? (
            <>
              <button
                className="s-x"
                aria-label="حذف"
                onClick={(e) => {
                  e.stopPropagation();
                  setSlotA(null);
                }}
              >
                <Icon name="x" />
              </button>
              <span className="s-lab">ظرف {toFa(1)}</span>
              <span className="s-sym">{slotA.sym}</span>
              <span className="s-fa">{slotA.fa}</span>
              <span className="s-z mono">Z = {slotA.z}</span>
            </>
          ) : (
            <>
              <span className="s-lab">ظرف {toFa(1)}</span>
              <span className="s-sym" style={{ opacity: 0.25 }}>—</span>
              <span className="s-fa">انتخاب عنصر</span>
            </>
          )}
        </button>

        <div className="flask-wrap" id="flaskWrap" ref={flaskWrapRef}>
          <svg className="flask" viewBox="0 0 420 460" preserveAspectRatio="xMidYMid meet">
            <path d="M186 22 V156 M234 22 V156 M174 22 H246" className="rim" />
            <circle cx="210" cy="295" r="140" />
            <ellipse cx="210" cy="446" rx="120" ry="7" fill="rgba(236,228,212,.05)" stroke="none" />
          </svg>
          <canvas id="rxC" ref={rxCanvasRef} />
          <div className="flask-empty" style={{ opacity: flaskBusy ? 0 : 1 }}>
            دو عنصر انتخاب کن
            <br />
            و شعله را روشن کن
          </div>
        </div>

        <button
          className={`slot slotB ${slotB ? 'filled' : ''}`}
          style={{ ['--c' as string]: slotB?.col || 'transparent' }}
          onClick={(e) => {
            if ((e.target as HTMLElement).closest('.s-x')) {
              setSlotB(null);
              return;
            }
            openPicker('B');
          }}
        >
          {slotB ? (
            <>
              <button
                className="s-x"
                aria-label="حذف"
                onClick={(e) => {
                  e.stopPropagation();
                  setSlotB(null);
                }}
              >
                <Icon name="x" />
              </button>
              <span className="s-lab">ظرف {toFa(2)}</span>
              <span className="s-sym">{slotB.sym}</span>
              <span className="s-fa">{slotB.fa}</span>
              <span className="s-z mono">Z = {slotB.z}</span>
            </>
          ) : (
            <>
              <span className="s-lab">ظرف {toFa(2)}</span>
              <span className="s-sym" style={{ opacity: 0.25 }}>—</span>
              <span className="s-fa">انتخاب عنصر</span>
            </>
          )}
        </button>
      </div>

      <div className="controls">
        <button className="btn" onClick={onMix}>
          <Icon name="flame" />
          شعله‌ور کن
        </button>
        <button className="btn ghost" onClick={onRandom}>
          <Icon name="shuffle" />
          واکنش تصادفی
        </button>
        <button className="btn ghost" onClick={onClear}>
          <Icon name="eraser" />
          پاک‌کردن
        </button>
      </div>

      <div className="famous">
        <span>ترکیب‌های معروف:</span>
        <button className="fch" onClick={() => onFamous(12, 8)}>Mg + O</button>
        <button className="fch" onClick={() => onFamous(11, 17)}>Na + Cl</button>
        <button className="fch" onClick={() => onFamous(1, 8)}>H + O</button>
        <button className="fch" onClick={() => onFamous(26, 6)}>Fe + C (فولاد)</button>
        <button className="fch" onClick={() => onFamous(54, 9)}>Xe + F (استثنا!)</button>
      </div>

      {resultVisible && result && <ResultCard res={result} />}

      <div style={{ height: 90 }} />

      {pickerOpen && (
        <div
          className="modal-bd open"
          onClick={(e) => {
            if (e.target === e.currentTarget) setPickerOpen(false);
          }}
        >
          <div className="modal">
            <div className="m-head">
              <h3>انتخاب عنصر</h3>
              <button className="icon-btn" onClick={() => setPickerOpen(false)}>
                <Icon name="x" />
              </button>
            </div>
            <div className="m-search">
              <Icon name="search" />
              <input
                autoFocus
                value={pickSearch}
                onChange={(e) => setPickSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    const first = E.filter((el) => pickFilter(el, pickQ))[0];
                    if (first) handlePick(first.z);
                  }
                }}
                placeholder="جست‌وجو… مثلا: منیزیم یا Mg"
              />
            </div>
            <div className="m-grid">
              {E.filter((el) => pickFilter(el, pickQ)).map((el) => (
                <button
                  key={el.z}
                  className="pt"
                  style={{ ['--c' as string]: el.col }}
                  onClick={() => handlePick(el.z)}
                >
                  <i>{el.z}</i>
                  <b>{el.sym}</b>
                  <span>{el.fa}</span>
                </button>
              ))}
            </div>
            <p className="m-hint">کلید Enter اولین نتیجه را انتخاب می‌کند.</p>
          </div>
        </div>
      )}

      {toastMsg && <div className="toast show">{toastMsg}</div>}

      {/* Hidden tick to satisfy unused-state usage */}
      <span style={{ display: 'none' }} aria-hidden>{resetTick}</span>
    </>
  );
}

function ResultCard({ res }: { res: ReactionResult }) {
  if (res.type === 'none') {
    return (
      <div className="result show">
        <p className="r-none">
          <b style={{ color: 'var(--fb-acc2)', fontFamily: 'var(--fb-disp)', fontSize: 30, display: 'block' }}>
            واکنشی رخ نداد!
          </b>
          {res.a.sym} و {res.b.sym} کنار هم آرام گرفتند.
          <br />
          {res.note}
        </p>
      </div>
    );
  }

  if (res.type === 'al') {
    return (
      <div className="result show">
        <div className="r-formula" style={{ fontSize: 34 }}>
          {res.a.sym} <span style={{ color: 'var(--fb-ink2)' }}>+</span> {res.b.sym}
        </div>
        <div className="r-name">{res.name}</div>
        <div className="r-chips">
          <span>
            <Icon name="link" />
            پیوند: <b>{res.bond}</b>
          </span>
          <span>
            <Icon name="zap" />
            <b>{res.kind}</b>
          </span>
        </div>
        <p className="r-note">{res.note}</p>
      </div>
    );
  }

  // 'cpd' or 'mol'
  const fHtml = (sym: string, n?: number) => sym + (n && n > 1 ? `<sub>${n}</sub>` : '');
  let formula: string;
  let eq: string | undefined;
  if (res.type === 'mol') {
    formula = fHtml(res.a.sym, 2);
    eq = `${res.a.sym} + ${res.a.sym} <span class="arr">→</span> ${fHtml(res.a.sym, 2)}`;
  } else {
    formula = fHtml(res.fA!.sym, res.nA) + fHtml(res.fB!.sym, res.nB);
    eq = res.eq;
  }

  return (
    <div className="result show">
      <div className="r-formula" dangerouslySetInnerHTML={{ __html: formula }} />
      <div className="r-name">{res.name}</div>
      <div className="r-chips">
        <span>
          <Icon name="link" />
          پیوند: <b>{res.bond}</b>
        </span>
        <span>
          <Icon name="zap" />
          <b>{res.kind}</b>
        </span>
        {res.mass ? (
          <span>
            <Icon name="scale" />
            جرم مولی: <b className="mono" dir="ltr">{res.mass} g/mol</b>
          </span>
        ) : null}
        <span>
          <Icon name="atom" />
          اتم‌ها: <b>{res.type === 'mol' ? 2 : (res.nA || 0) + (res.nB || 0)}</b>
        </span>
      </div>
      {eq && (
        <div className="r-eq" dangerouslySetInnerHTML={{ __html: eq }} />
      )}
      <p className="r-note">{res.note}</p>
    </div>
  );
}
